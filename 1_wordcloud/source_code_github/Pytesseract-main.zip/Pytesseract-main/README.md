# Pytesseract

Building word clouds, text to audio 
